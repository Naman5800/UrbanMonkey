import React from 'react';
import { SignIn } from '@clerk/clerk-react';

const SignInModal = ({ isOpen, onClose, redirectUrl }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 max-w-md w-full">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Sign In to Continue</h2>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            ✕
          </button>
        </div>
        <SignIn 
          redirectUrl={redirectUrl || window.location.pathname}
          routing="path"
          path="/sign-in"
          signUpUrl="/sign-up"
          afterSignInUrl={redirectUrl || window.location.pathname}
        />
      </div>
    </div>
  );
};

export default SignInModal;