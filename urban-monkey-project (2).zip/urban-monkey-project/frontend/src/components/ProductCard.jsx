import React from "react";
import { FaHeart, FaShoppingCart } from "react-icons/fa";
import { Link } from "react-router-dom";

const ProductCard = ({ product }) => {
  const handleAddToCart = (e) => {
    e.preventDefault();
    const existingCart = JSON.parse(sessionStorage.getItem('cart') || '[]');
    const existingItemIndex = existingCart.findIndex(item => item.productId === product._id);
    if (existingItemIndex > -1) {
      existingCart[existingItemIndex].quantity += 1;
    } else {
      existingCart.push({
        productId: product._id,
        name: product.name,
        price: product.price,
        image: product.image,
        quantity: 1
      });
    }
    sessionStorage.setItem('cart', JSON.stringify(existingCart));
    alert('Product added to cart!');
    console.log("Updated cart:", existingCart);
  };

  const handleAddToWishlist = (e) => {
    e.preventDefault();
    const existingWishlist = JSON.parse(sessionStorage.getItem('wishlist') || '[]');
    if (!existingWishlist.some(item => item.productId === product._id)) {
      existingWishlist.push({
        productId: product._id,
        name: product.name,
        price: product.price,
        image: product.image
      });
      sessionStorage.setItem('wishlist', JSON.stringify(existingWishlist));
      alert("Added to wishlist!");
    } else {
      alert("Product already in wishlist!");
    }
    console.log("Updated wishlist:", existingWishlist);
  };

  return (
    <div className="block">
      <div className="relative bg-white shadow-md rounded-lg overflow-hidden transform transition hover:scale-105 w-full h-auto text-center">
        <div className="absolute top-3 right-3 flex flex-col space-y-2 z-10">
          <div onClick={handleAddToWishlist}>
            <FaHeart className="text-gray-600 hover:text-red-500 cursor-pointer text-lg" />
          </div>
          <div onClick={handleAddToCart}>
            <FaShoppingCart className="text-gray-600 hover:text-blue-600 cursor-pointer text-lg" />
          </div>
        </div>

        <Link to={`/product/${product._id}`}>
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-64 object-cover"
          />
          <div className="p-5">
            <h3 className="font-bold text-l">{product.name}</h3>
            <p className="text-gray-600">${product.price}</p>
          </div>
        </Link>
      </div>
    </div>
  );
};

export default ProductCard;